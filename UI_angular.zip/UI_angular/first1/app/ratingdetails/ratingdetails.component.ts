import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratingdetails',
  templateUrl: './ratingdetails.component.html',
  styleUrls: ['./ratingdetails.component.css']
})
export class RatingdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
