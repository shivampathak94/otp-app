import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emplportal',
  templateUrl: './emplportal.component.html',
  styleUrls: ['./emplportal.component.css']
})
export class EmplportalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
