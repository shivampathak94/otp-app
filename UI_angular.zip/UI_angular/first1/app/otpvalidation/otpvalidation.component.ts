import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otpvalidation',
  templateUrl: './otpvalidation.component.html',
  styleUrls: ['./otpvalidation.component.css']
})
export class OtpvalidationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
