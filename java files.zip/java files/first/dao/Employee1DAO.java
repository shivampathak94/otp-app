package com.prac1.springdemo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prac1.springdemo.entity.entity.EmployeeRegistration1;

public interface Employee1DAO extends JpaRepository<EmployeeRegistration1, String> {

}
